Board outline defined be 10mil trace on on all gerber files

Board dimensions are 3in. x 3.5in.